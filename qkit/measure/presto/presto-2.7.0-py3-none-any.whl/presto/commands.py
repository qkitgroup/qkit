(
    Reset,
    Version,
    Echo,
    Sleep,
    LoadFirmware,
    NrPorts,
    ErrorList,
    WhichBoard,
    ClockInit,
    ClockSync,
    ClockSetLmx,
    PrestoInit,
    PrestoVarVer,
    PrestoRpuVer,
    PrestoRun,
    PrestoDmaStart,
    PrestoDmaWait,
    PrestoDmaStop,
    PrestoDmaGet,
    PrestoDmaStatus,
    PrestoOcmError,
    PrestoConvMode,
    PrestoDcBias,
    PrestoDcRaw,
    PrestoDcReadback,
    PrestoMarkerIn,
    PrestoMarkerOut,
    TestDither,
    TestFrequency,
    TestPhase,
    TestScale,
    TestBlank,
    TestDmaSrc,
    PlsStoreMode,
    PlsStoreCmd,
    PlsScale,
    PlsMatchTmpl,
    PlsOutTmpl,
    PlsFreqLut,
    PlsPhaseLutI,
    PlsPhaseLutQ,
    PlsEnvelope,
    PlsMatchCmd,
    PlsOutCmd,
    PlsDigCmd,
    PlsNIter,
    PlsMatchMux,
    PlsFbDefaultMask,
    PlsFbConditionMask,
    PlsFbUserMask,
    PlsFbInvertCondition,
    PlsFbCompareConstant,
    PlsFbCompareIQ,
    LckSetInFreqPhase,
    LckSetOutFreqPhase,
    LckSetScale,
    LckSetDf,
    LckGet,
    LckAbort,
    LckGroupMask,
    LckInputSelect,
    RfdcInit,
    RfdcMts,
    RfdcSetNCO,
    RfdcDefaultConfig,
    RfdcConfig,
    RfdcNyquist,
    RfdcSync,
    RfdcCalFreeze,
    RfdcCalSave,
    RfdcCalRestore,
    RfdcMultiBand,
    RfdcSetInvSinc,
    RfdcSetDacCurrent,
    RfdcSetDSA,
    Quit,
    IntrStatus,
    IntrClr,
) = range(78)

AdcDirect = 0
AdcMixed = 1

DacDirect = 0
DacMixed02 = 1
DacMixed04 = 2
DacMixed42 = 3

AdcG2 = 0
AdcG3_2 = 1
AdcG4 = 2

DacG2 = 0
DacG4 = 1
DacG6 = 2
DacG6_4 = 3
DacG8 = 4
DacG10 = 5
