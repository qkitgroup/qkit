# Copyright (C) Intermodulation Products AB, 2018 - All Rights Reserved.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential. Please refer to file LICENSE for details.
"""
Continuous-wave generation and measurement.

Detailed information is provided in the documentation for each class.

.. autosummary::
    :nosignatures:

    Lockin
    SymmetricLockin
    InputGroup
    OutputGroup
    SymmetricGroup

**Converter modes** (re-exported from :mod:`hardware <presto.hardware>` module):

  .. autoclass:: AdcMode

     See :class:`AdcMode <presto.hardware.AdcMode>` for full documentation

  .. autoclass:: DacMode

     See :class:`DacMode <presto.hardware.DacMode>` for full documentation

**Converter sampling rates** (re-exported from :mod:`hardware <presto.hardware>` module):

  .. autoclass:: AdcFSample

     See :class:`AdcFSample <presto.hardware.AdcFSample>` for full documentation

  .. autoclass:: DacFSample

     See :class:`DacFSample <presto.hardware.DacFSample>` for full documentation
"""

import math
from typing import List, Optional, Union

import numpy as np

from . import commands as cmd
from .hardware import AdcFSample, AdcMode, DacFSample, DacMode, Hardware
from .utils import as_flat_list
from .version import version_fpga as VERSION

NR_LCK_FREQ = 192
NR_GROUPS = 16
FREQ_PER_GROUP = NR_LCK_FREQ // NR_GROUPS
_MAX_TRIGGER_CLK = (1 << 24) - 1


class Lockin:
    VARIANT = 7

    def __init__(
        self,
        *,
        ext_ref_clk=False,
        force_reload=False,
        dry_run=False,
        address=None,
        port=None,
        adc_mode=AdcMode.Direct,
        adc_fsample=AdcFSample.G2,
        dac_mode=DacMode.Direct,
        dac_fsample=DacFSample.G4,
        force_config=False,
    ):
        r"""Use the hardware in continuous-wave mode.

        Warnings
        --------
        Create only one instance at a time. This class is designed to be instantiated with Python's :ref:`with
        statement <python:with>`, see Examples section.

        Parameters
        ----------
        ext_ref_clk : optional
            if :obj:`None` or :obj:`False` use internal reference clock; if :obj:`True` use external reference clock
            (10 MHz); if :class:`float` or :class:`int` use external reference clock at `ext_ref_clk` Hz
        force_reload : bool, optional
            if :obj:`True` re-configure clock and reload firmware even if there's no change from the previous settings.
        dry_run : bool, optional
            if :obj:`False` don't connect to hardware, for testing only.
        address : str, optional
            IP address or hostname of the hardware. If :obj:`None`, use factory default `"192.168.42.50"`.
        port : int, optional
            port number of the server running on the hardware. If :obj:`None`, use factory default `7878`.
        adc_mode : hardware.AdcMode or list, optional
            configure the inputs to sample in direct mode (default), or to use the digital mixers for downconversion.
            See Notes.
        adc_fsample : hardware.AdcFSample or list, optional
            configure the inputs sampling rate (default 2 GS/s). See Notes.
        dac_mode : hardware.DacMode or list, optional
            configure the outputs to work in direct mode (default), to use the digital mixers for upconversion. See
            Notes.
        dac_fsample : hardware.DacFSample or list, optional
            configure the outputs sampling rate (default 4 GS/s). See Notes.
        force_config : bool, optional
            if :obj:`True` skip checks on `DacMode`\ s not recommended for high DAC sampling rates.

        Raises
        ------
        ValueError
            if `adc_mode` or `dac_mode` are not valid :ref:`converter modes`;
            if `adc_fsample` or `dac_fsample` are not valid :ref:`converter rates`.

        Notes
        -----
        In all the Examples, it is assumed that the imports ``import numpy as np`` and ``from presto import lockin``
        have been performed, and that this class has been instantiated in the form ``lck = lockin.Lockin()``, or,
        **much much better**, using the ``with lockin.Lockin() as lck`` construct as below.

        For valid values of `adc_mode` and `dac_mode`, see :ref:`converter modes`. For valid values of `adc_fsample`
        and `dac_fsample`, see :ref:`converter rates`. For advanced configuration, e.g. different converter rates on
        different ports, see :ref:`adv tile`.
        """
        self.dry_run = bool(dry_run)

        adc_mode, adc_fsample, dac_mode, dac_fsample = Hardware.validate_config(
            adc_mode, adc_fsample, dac_mode, dac_fsample, force_config=force_config
        )

        # this API only supports either all tiles Direct or all tiles Mixed
        # ADC and DAC can be different
        # different types of Mixed (DAC gen3) are fine
        if 0 < np.sum(adc_mode == AdcMode.Direct) < 4:
            raise NotImplementedError(
                "all ADC tiles must be configured with the same mode (all Direct or all Mixed)"
            )
        if 0 < np.sum(dac_mode == DacMode.Direct) < 4:
            raise NotImplementedError(
                "all DAC tiles must be configured with the same mode type (all Direct or any combination of MixedXX)"
            )
        self.adc_direct = adc_mode[0] == AdcMode.Direct
        self.dac_direct = dac_mode[0] == DacMode.Direct

        if 0 < np.sum(adc_fsample == AdcFSample.G3_2) < 4:
            raise NotImplementedError(
                "if adc_fsample=AdcFSample.G3_2 on one tile, then all ADC tiles must use it"
            )
        if 0 < np.sum(dac_fsample == DacFSample.G6_4) < 4:
            raise NotImplementedError(
                "if dac_fsample=DacFSample.G6_4 on one tile, then all DAC tiles must use it"
            )
        if (AdcFSample.G3_2 in adc_fsample) ^ (DacFSample.G6_4 in dac_fsample):
            raise NotImplementedError(
                "adc_fsample=AdcFSample.G3_2 and dac_fsample=DacFSample.G6_4 must be used together"
            )

        self.CLK_T = 2.5e-9 if adc_fsample[0] == AdcFSample.G3_2 else 2e-9
        self.CLK_F = 400e6 if adc_fsample[0] == AdcFSample.G3_2 else 500e6

        self._apply_required = True
        self._df = 1e3
        # self._nsum = 250
        self._reset_phase = True
        self._trigctrl = 0
        self._trigstart = 0
        self._trigwidth = 0
        self._input_frequencies = np.zeros(NR_LCK_FREQ, np.float64)
        self._input_phases_i = np.zeros(NR_LCK_FREQ, np.float64)
        self._input_phases_q = np.zeros(NR_LCK_FREQ, np.float64)
        self._input_select = np.zeros(NR_GROUPS, np.int64)
        self._input_used = np.zeros(NR_LCK_FREQ, bool)
        self._input_map = []
        self._output_frequencies = np.zeros(NR_LCK_FREQ, np.float64)
        self._output_phases_i = np.zeros(NR_LCK_FREQ, np.float64)
        self._output_phases_q = np.zeros(NR_LCK_FREQ, np.float64)
        self._output_scales = np.zeros(NR_LCK_FREQ, np.float64)
        self._output_mask = np.zeros(16, np.int64)
        self._output_used = np.zeros(NR_LCK_FREQ, bool)
        self._output_groups: list[OutputGroup | SymmetricGroup] = []
        self._input_groups: list[InputGroup | SymmetricGroup] = []

        self._nr_ports = 16  # changed below after connecting to the hardware
        self._board = None  # changed below after connecting to the hardware
        self.hardware = Hardware(address, port, dry_run)
        """Hardware: interface to hardware features common to all modes of operation"""

        try:
            if not self.dry_run:
                if force_reload:
                    self.hardware.reset()
                self.hardware.init_clock(ext_ref_clk)
                self.hardware.load_firmware(f"presto_{self.VARIANT:d}_{VERSION:d}.bin")
                self.hardware.init_presto()
                self.hardware.init_rfdc()

                var, ver = self.hardware.get_var_ver()
                if var != self.VARIANT:
                    raise RuntimeError(
                        f"The loaded firmware variant {var} does not match the expected {self.VARIANT}."
                        " This should not happen, please contact Intermodulation Products for support."
                    )
                if ver != VERSION:
                    raise RuntimeError(
                        "The version of the firmware running on the hardware is not compatible with the current API:"
                        f" got {ver}, expected {VERSION}. Have you updated both the API on the computer and the"
                        " software/firmware on the Vivace/Presto hardware?"
                    )
                self._nr_ports = self.hardware.get_nr_ports()
                self._board = self.hardware.get_board_name()

            # apply settings now to reset all frequencies, phases and scales to zero
            # otherwise we can run into trouble when changing rfdc mode later
            self.apply_settings()

            # set user-requested configuration for the data converters
            self.hardware.setup_config(
                adc_mode, adc_fsample, dac_mode, dac_fsample, force_config=force_config
            )
            # then we do MTS to align the FIFOs
            self.hardware.mts()
            self.hardware.assert_errors()

            self.hardware.intr_clr()
            _ = self.hardware.get_intr_status()  # the first after MTS is polluted
            self.hardware.check_adc_intr_status()
        except (Exception, KeyboardInterrupt):
            self.close()
            raise

    def __enter__(self):  # for use with 'with' statement
        return self

    def __exit__(self, exc_type, exc_value, traceback):  # for use with 'with' statement
        self.close()

    def close(self):
        """Gracely disconnect from the hardware.

        Call this method if the class was instantiated without a :ref:`with statement <python:with>`. This method is
        called automatically when exiting a ``with`` block and before the object is destructed.
        """
        if self.hardware is not None:
            self.hardware.close()

    def check_current_consumption(self):
        # TODO: update estimates on current consumption

        # if self._board == "zcu111":
        #     # estimate power consumption
        #     nr_outputs = np.sum(self._output_frequencies > 0)
        #     nr_input_pairs = np.sum(self._input_frequencies > 0) // 2
        #     if nr_outputs > 0 or nr_input_pairs > 0:
        #         (q_static, m_out,
        #          m_in) = (16.75, 0.082, 0.144) if self.hardware.adc_fsample[0] == AdcFSample.G3_2 else (20.75, 0.101,
        #                                                                                                 0.176)
        #         current = q_static + m_out * nr_outputs + m_in * nr_input_pairs
        #         if current > 30.0:
        #             raise RuntimeError(f"the requested configuration would consume too much power: {current} A."
        #                                "Consider decreasing the number of input/output frequencies")
        pass

    def apply_settings(self):
        """Apply the settings to the hardware.

        Notes
        -----
        Prior to a call to this function, any change of settings has no effect on the hardware.
        """
        self._clear_outputs()
        self._clear_inputs()

        for og in self._output_groups:
            assert isinstance(og, OutputGroup)
            self._add_output(
                og.ports,
                og._output_frequencies,
                og._output_scales,
                og._output_phases_i,
                og._output_phases_q,
            )
        for ig in self._input_groups:
            assert isinstance(ig, InputGroup)
            self._add_input(ig.port, ig._input_frequencies, ig._input_phases_i)

        self.check_current_consumption()

        if not self.dry_run:
            # disable outputs
            self.hardware.blank_output(range(1, self._nr_ports + 1), True)

            # send settings
            self.hardware.send_command(
                cmd.LckSetInFreqPhase,
                len(self._input_frequencies),
                *self._input_frequencies,
                *self._input_phases_i,
                *self._input_phases_q,
            )
            self.hardware.send_command(
                cmd.LckSetOutFreqPhase,
                len(self._output_frequencies),
                *self._output_frequencies,
                *self._output_phases_i,
                *self._output_phases_q,
            )

            self.hardware.send_command(
                cmd.LckSetScale, len(self._output_scales), *self._output_scales
            )
            self.hardware.send_command(
                cmd.LckSetDf,
                self.get_df(),
                1 if self._reset_phase else 0,
                self._trigctrl,
                self._trigstart,
                self._trigstart + self._trigwidth,
            )

            for channel in range(self._nr_ports):
                self.hardware.send_command(cmd.LckGroupMask, channel, self._output_mask[channel])

            for i in range(NR_GROUPS):
                self.hardware.send_command(cmd.LckInputSelect, i, self._input_select[i])

            # enable outputs
            self.hardware.sleep(self.get_Tm(), False)
            self.hardware.blank_output(range(1, self._nr_ports + 1), False)

            self.hardware.assert_errors()
        self._apply_required = False

    def tune(self, f, df):
        r"""Perform standard level of tuning.

        This provides frequencies closer to the requested ones, with a level of Fourier leakage that is adequate to
        most experiments. See Notes.

        Parameters
        ----------
        f : float or array_like
            Target frequency/ies in Hz
        df : float
            Target measurement bandwidth in Hz

        Returns
        -------
        f_tuned : float or numpy.ndarray
            Tuned frequencies in Hz
        df_tuned : float
            Tuned measurement bandwith in Hz

        See also
        --------
        tune_perfect : perfect tuning
        set_phase_reset : enable/disable phase reset every `1/df`

        Notes
        -----
        First, this level of tuning forces the measurement bandwith `df` to be a divisor of the sampling frequency
        `fs`, i.e. there is an integer number of samples `ns = fs/df_tuned` in each lock-in measurement window. Second,
        the tuning forces each frequency `f` to be integer multiple of the measurement bandwith `df_tuned`, i.e. there
        is an integer number `n = f_tuned/df_tuned` of oscillations within each measurement window.

        In theory, this level of tuning allows for measurement without Fourier leakage, or spectral leakage. In
        practice, however, not every value of `f_tuned` can be represented exactly in the hardware. With this level of
        tuning, the frequency that is actually set in hardware `f_set` is slightly different from the tuned frequency
        `f_tuned`. Therefore, the ratio `f_set/df_tuned` is not an integer, and some Fourier leakage occurs. To avoid
        long-term phase drift, the phase of the oscillation at frequency `f_set` is reset at the end of each lock-in
        window (every `1/df_tuned`). See :meth:`set_phase_reset` for a way to disable this behavior.

        Nonetheless, the difference between `f_set` and `f_tuned` is actually really small: the worst-case error is
        `get_fs("dac")/2/2**48`, on the order of a single microhertz (:math:`1 \mathrm{\mu Hz}`)! For most common
        applications, the resulting Fourier leakage and the phase-reset glitches are well below the noise level. If
        however, this is not acceptable, see :meth:`tune_perfect`.
        """
        # in general, df must correspond to an integer number of samples
        # but more stringent: it must correspond to an integer number of clock cycles (4 samples in direct mode)
        df = float(df)
        ns_tuned = int(round(self.CLK_F / df))
        df_tuned = self.CLK_F / ns_tuned

        f_tuned = df_tuned * np.int64(np.round(f / df_tuned))
        return f_tuned, df_tuned

    def tune_perfect(self, f, df):
        """Perform perfect level of tuning.

        This provides frequencies that might be further from the requested ones, but with zero Fourier leakage. See
        Notes.

        Parameters
        ----------
        f : float or array_like
            Target frequency/ies in Hz
        df : float
            Target measurement bandwidth in Hz

        Returns
        -------
        f_tuned : float or numpy.ndarray
            Tuned frequency/ies in Hz
        df_tuned : float
            Tuned measurement bandwith in Hz

        See also
        --------
        tune : standard tuning

        Notes
        -----
        First, this level of tuning forces the measurement bandwith `df` to divide the sampling frequency `fs` by a
        power of 2, i.e. the number of samples in each lock-in measurement window is a power of 2: `ns = fs/df_tuned =
        2**m`. Second, the tuning forces each frequency `f` to be integer multiple of the measurement bandwith
        `df_tuned`, i.e. there is an integer number `n = f_tuned/df_tuned` of oscillations within each measurement
        window.

        This level of tuning always allows for measurement without Fourier leakage, or spectral leakage, and guarantees
        that `f_tuned` can be represented exactly in the hardware.
        """
        fs = self.CLK_F  # tune with respect to clock frequency
        ns = fs / df
        ns_tuned = 2 ** np.int64(np.round(np.log2(ns)))
        df_tuned = fs / ns_tuned
        f_tuned = df_tuned * np.int64(np.round(f / df_tuned))
        return f_tuned, df_tuned

    def get_clk_f(self):
        """Frequency of the programmable-logic clock in Hz.

        Returns
        -------
        float

        See also
        --------
        get_clk_T
        get_fs
        """
        return self.CLK_F

    def get_clk_T(self):
        """Period of the programmable-logic clock in seconds.

        Returns
        -------
        float

        See also
        --------
        get_clk_f
        get_fs
        """
        return self.CLK_T

    def get_fs(self, which):
        """Get sampling frequency for `which` converter.

        Parameters
        ----------
        which : str
            "adc" for input and "dac" for output.

        Returns
        -------
        fs : float

        Raises
        ------
        ValueError
            if `which` is unknown.
        """
        if which == "adc":
            if self.adc_direct:
                return 4 * self.get_clk_f()
            else:
                return 2 * self.get_clk_f()
        elif which == "dac":
            if self.dac_direct:
                return 4 * self.get_clk_f()
            else:
                return 2 * self.get_clk_f()
        else:
            raise ValueError(f"`which` can be 'adc' or 'dac', got {which}")

    def get_df(self):
        """Get measurement bandwidth.

        Returns
        -------
        df : float
            Measurement bandwith in Hz.

        See also
        --------
        set_df
        get_Tm
        """
        return self._df

    def set_df(self, df):
        """Set measurement bandwith.

        *The new setting is not applied until* :meth:`apply_settings` *is called!*

        Parameters
        ----------
        df : float
            Measurement bandwith in Hz.

        Notes
        -----
        Non-tuned measurement bandwidths can't be set in hardware. When passing a non-tuned `df`, the closest tuned
        value will be set in hardware. To avoid confusion, it is recommended to explicitly tune `df` before calling
        this method.

        See also
        --------
        get_df
        tune
        tune_perfect
        """
        self._apply_required = True
        df = float(df)
        # df must correspond to an integer number of clock cycles
        # NOTE: this is the same as standard tuning!
        period = int(round(self.CLK_F / df))
        self._df = self.CLK_F / period

    def set_phase_reset(self, reset_phase: bool) -> None:
        """Reset the phase of the reference signals at the end of every lock-in window.

        *The new setting is not applied until* :meth:`apply_settings` *is called!*

        Parameters
        ----------
        reset_phase
            if :obj:`True` the phase reset is enabled, set to :obj:`False` to disable.

        Notes
        -----
        This setting is enabled by default. See Notes in :meth:`tune` for rationale.
        """
        self._reset_phase = bool(reset_phase)

    def _time_to_clk(self, t: float, check: bool = False) -> int:
        """Convert `t` to an integer number of clock cycles, round if needed."""
        t = float(t)
        c = int(round(t * self.CLK_F))
        if check:
            if c < 0:
                raise ValueError("`t` must be nonnegative")
            if abs(c * self.CLK_T - t) > self.CLK_T / 100:
                raise ValueError(f"`t`={t} is not a multiple of the clock period {self.CLK_T}")
        return c

    def set_trigger_out(
        self, states: Union[int, List[int]], delay: float = 0.0, width: float = 100e-9
    ) -> None:
        """Output a trigger on the digital output ports at the start of every demodulation or summing window.

        Times will be rounded to closest integer multiple of :meth:`get_clk_T`.

        Parameters
        ----------
        states
            enable/disable the trigger on each of the digital output ports. Valid values are: 0 no
            trigger output, 1 trigger for each new lock-in window, 2 trigger for each new sum
            window (mean and std)
        delay
            delay trigger rising edge from start of lock-in window, in seconds
        width
            trigger-high duration, in seconds

        Raises
        ------
        ValueError
            if `delay` and `width` are negative, or too large

        Examples
        --------
        Output a 100ns trigger on port 1 every summing window and on port 2 every demodulation window:

        >>> lck.set_trigger_out([2, 1])
        """
        states = as_flat_list(states)
        control = 0
        for ii, state in enumerate(states):
            if state < 3:
                control |= state << (2 * ii)
            else:
                raise ValueError("`state` can be 0, 1 or 2")

        start = self._time_to_clk(delay)
        if start < 0 or start > _MAX_TRIGGER_CLK:
            raise ValueError(
                f"`delay` must be between 0 and {_MAX_TRIGGER_CLK*self.CLK_T} seconds"
            )
        width = self._time_to_clk(width)
        if width < 1 or width > _MAX_TRIGGER_CLK:
            raise ValueError(
                f"`width` must be within {self.CLK_T} and {_MAX_TRIGGER_CLK*self.CLK_T} seconds"
            )

        self._trigctrl = control
        self._trigstart = start
        self._trigwidth = width

    def get_Tm(self):
        """Get measurement time.

        The inverse of the measurement bandwidth.

        Returns
        -------
        Tm : float
            Measurement time in seconds.

        See also
        --------
        get_df
        """
        df = self.get_df()
        return 1.0 / df

    def get_ns(self, which="adc"):
        """Get number of samples per lock-in window.

        The sampling rate divided by the measurement bandwidth.

        Returns
        -------
        ns : int
        """
        return int(round(self.get_fs(which=which) / self.get_df()))

    def _clear_outputs(self):
        """Clears all outputs.

        Clears all outputs so that :meth:`add_output` starts from scratch.
        Not applied until :meth:`apply_settings` is called!
        """
        self._output_frequencies.fill(0.0)
        self._output_phases_i.fill(0.0)
        self._output_phases_q.fill(0.0)
        self._output_scales.fill(0.0)
        self._output_mask.fill(0)
        self._output_used.fill(False)

    def _add_output(self, ports, freqs, amps, phases, phases_q=None, deg=False):
        """Add output signals to ports

        The new setting is not applied until :meth:`apply_settings` is called!

        Parameters
        ----------
        ports  : int or array_like
            The ports to output these settings on.
        freqs  : float or array_like
            Lock-in frequency/ies in Hz.
        amps   : float or array_like
            Output amplitudes with +/- 1.0 being full scale.
        phases : float or array_like
            Output phases in rad/deg. If less than available number of frequencies, set the rest to zero. When using
            the digital mixers, sets the phase of the I port of the mixer.
        phases_q : float or array_like, optional
            When using the digital mixers, sets the phase of the Q port of the mixer. In direct mode, setting phases_q
            throws an error.
        deg : bool, optional
            Set the phases in degrees in `[-180.0, +180.0]`. Default is radians in `[-np.pi, +np.pi]`.

        Returns
        -------
        freqs : numpy.ndarray
            Lock-in frequencies in Hz. `dtype` is :class:`float`
        amps_set : numpy.ndarray
            Output amplitudes (that will be) set in the hardware. `dtype` is :class:`float`.
        phases_set : numpy.ndarray
            Output phases in rad/deg (that will be) set in the hardware. `dtype` is :class:`float`.
        phases_q_set : numpy.ndarray
            Output phases in rad/deg (that will be) set in the hardware. `dtype` is :class:`float`.
        """
        ports = np.atleast_1d(ports).astype(np.int64)
        freqs = np.atleast_1d(np.abs(freqs)).astype(np.float64)
        phases = np.atleast_1d(phases).astype(np.float64)
        amps = np.atleast_1d(amps).astype(np.float64)

        if self.dac_direct:
            if phases_q is not None:
                raise ValueError("setting `phases_q` is not allowed if `dac_mode` is `DacDirect`!")
        else:
            if phases_q is None:
                raise ValueError("must provide `phases_q` if `dac_mode` is not `DacDirect`!")
            phases_q = np.atleast_1d(phases_q).astype(np.float64)
            if phases_q.shape != phases.shape:
                raise ValueError("`phases_q` must have same shape as `phases`!")

        if deg:
            phases = phases / 180.0 * np.pi

        if np.any(np.abs(amps) > 1.0):
            raise ValueError("Max amplitude is 1.0")

        first = self._first_free_output()
        last = first + freqs.shape[0]
        if last > NR_LCK_FREQ:
            raise ValueError("Too many output frequencies used")
        self._output_frequencies[first:last] = freqs
        self._output_phases_i[first:last] = phases
        self._output_phases_q[first:last] = phases_q
        self._output_scales[first:last] = amps
        self._output_used[first:last] = True

        for port in ports:
            for bit in set(np.arange(first, last, dtype=np.int64) // FREQ_PER_GROUP):
                self._output_mask[port - 1] = self._output_mask[port - 1] | (1 << bit)

        self._resync_phases()

        if self.dac_direct:
            return freqs, amps, phases
        else:
            return freqs, amps, phases, phases_q

    def _clear_inputs(self):
        """Removes settings for all inputs."""
        self._input_frequencies.fill(0.0)
        self._input_phases_i.fill(0.0)
        self._input_phases_q.fill(0.0)
        self._input_select.fill(0)
        self._input_used.fill(False)
        self._input_map = []

    def _add_input(self, port, freqs, phases):
        """
        Parameters
        ----------
        port  : int
        freqs : int or array_like
        """
        if port in [x[0] for x in self._input_map]:
            raise ValueError("Can only add an input once")

        freqs = np.atleast_1d(np.abs(freqs)).astype(np.float64)
        freqs = freqs.repeat(2)  # I&Q

        first = self._first_free_input()
        last = first + freqs.shape[0]

        if last > NR_LCK_FREQ:
            raise ValueError("Too many input frequencies used")

        self._input_frequencies[first:last] = freqs
        self._input_phases_i[first:last:2] = phases
        self._input_phases_i[first + 1 : last : 2] = phases + np.pi / 2

        for i in set(np.arange(first, last, dtype=np.int64) // FREQ_PER_GROUP):
            self._input_select[i] = port - 1
        self._input_used[first:last] = True
        if len(self._input_map) == 0:
            self._input_map.append((port, first, last, first, last))
        else:
            tot_used = self._input_map[-1][4]
            self._input_map.append((port, first, last, tot_used, tot_used + (last - first)))

        self._resync_phases()

    def add_output_group(self, ports, nr_freq) -> "OutputGroup":
        """Create and return a new :class:`output group <presto.lockin.OutputGroup>`

        Parameters
        ----------
        ports : int or list of int
            which output port(s) the group should output data to. If a :class:`list`, the output will be replicated on
            all `ports`
        nr_freq : int
            how many frequencies the output group should modulate

        Returns
        -------
        OutputGroup
        """
        g = OutputGroup(ports, nr_freq, self)
        self._output_groups.append(g)
        self._add_output(
            ports,
            np.zeros(nr_freq),
            np.zeros(nr_freq),
            np.zeros(nr_freq),
            None if self.dac_direct else np.zeros(nr_freq),
        )
        return g

    def add_input_group(self, port, nr_freq) -> "InputGroup":
        """Create and return a new :class:`input group <presto.lockin.InputGroup>`

        Parameters
        ----------
        port : int
            which input port the group should sample data from
        nr_freq : int
            how many frequencies the input group should demodulate

        Returns
        -------
        InputGroup
        """
        g = InputGroup(port, nr_freq, self)
        self._input_groups.append(g)
        self._add_input(port, np.zeros(nr_freq), np.zeros(nr_freq))
        return g

    def set_dither(self, state, output_ports):
        """Add pseudorandom noise to the generated output.

        Can improve harmonic and intermodulation distortion when working with small output amplitudes.

        *The change is active* **immediately**

        Parameters
        ----------
        state : bool
            if :obj:`True`, add pseudorandom noise to the output
        output_ports : int or list of int
            which output port(s) should be affected
        """
        output_ports = np.atleast_1d(output_ports).astype(np.int64)
        self._apply_required = True
        value = 1 if state else 0

        if not self.dry_run:
            for port in output_ports:
                channel = port - 1
                self.hardware.send_command(cmd.TestDither, channel, value)

    def get_pixels(
        self,
        n,
        summed: bool = False,
        fir_coeffs: Optional[List[float]] = None,
        nsum: int = 250,
        quiet: bool = False,
    ) -> dict:
        r"""Get lock-in packets (pixels) from the hardware.

        Parameters
        ----------
        n : int
            the number of lock-in packets to measure.
        summed : bool, optional
            when `True`, calculate on the hardware the mean and standard deviation of the acquired
            data in chunks of `nsum` lock-in packets.
        fir_coeffs : list of float, optional
            coefficients for FIR filter to be applied to measured data. 43 coefficients must be
            provided, or pass None (default) to disable the filter. See also *Notes* and *Examples*
            sections.
        nsum : int, optional
            ignored if `summed=False`. How many lock-in packets (at rate :meth:`get_df`\ ) The
            resulting data rate will be :meth:`get_df`\ `/ nsum`.
        quiet
            if True, don't check for inputs out of range

        Returns
        -------
        dict
            dictionary with key `port` and value depending on the value of `summed`.

            The key is always:

            * `port` (:class:`int`): input port measured

            When `summed=False` (default), the value is a tuple of:

            * `freqs` (:class:`np.ndarray <numpy.ndarray>`, `dtype=np.float64`): frequencies at
              which the lockin measurement was done.
            * `pixels` (:class:`np.ndarray <numpy.ndarray>`, `dtype=np.complex128`): measured
              lock-in data in ratio of full-scale input. `shape` is `(n, len(freqs))`. When using
              digital downconversion (`adc_mode` is :class:`AdcMode.Mixed
              <presto.hardware.AdcMode>`), these are the pixels of the I port of the digital mixer.
            * `pixels_q` (:class:`np.ndarray <numpy.ndarray>`, `dtype=np.complex128`): only present
              when using digital downconversion (`adc_mode` is :class:`AdcMode.Mixed
              <presto.hardware.AdcMode>`), these are the pixels of the Q port of the digital mixer.

            When `summed=True`, the value is a tuple of:

            * `freqs` (:class:`np.ndarray <numpy.ndarray>`, `dtype=np.float64`): frequencies at
              which the lockin measurement was done.
            * `mean_I` (:class:`np.ndarray <numpy.ndarray>`, `dtype=np.complex128`): calculated
              mean of `nsum` consecutive lock-in packets from the I port of the digital
              downconversion. `shape` is `(n, len(freqs))`.
            * `std_I` (:class:`np.ndarray <numpy.ndarray>`, `dtype=np.complex128`): calculated
              standard deviation of `nsum` consecutive lock-in packets from the I port of the
              digital downconversion. `shape` is `(n, len(freqs))`. The standard deviation has a
              real and an imaginary part; `abs(std)` is the total standard deviation according to
              `Complex random variable
              <https://en.wikipedia.org/wiki/Complex_random_variable#Variance_and_pseudo-variance>`_.
            * `mean_Q` (:class:`np.ndarray <numpy.ndarray>`, `dtype=np.complex128`): same as
              `mean_I`, but from the Q port.
            * `std_Q` (:class:`np.ndarray <numpy.ndarray>`, `dtype=np.complex128`): same as
              `std_I`, but from the Q port.

        Raises
        ------
        RuntimeError
            if :meth:`apply_settings` was not called after changing some setting

        Notes
        -----
        This method locks execution until at least `n` measured packets are available.

        `summed=True` is only implemented when using digital downconversion (`adc_mode` is
        :class:`AdcMode.Mixed <presto.hardware.AdcMode>`).

        Useful functions for computing the coefficients `fir_coeffs` for the FIR filter are
        :func:`remez <scipy.signal.remez>` and :func:`firwin <scipy.signal.firwin>` in the
        :mod:`scipy.signal` module.

        Examples
        --------
        Measure 1k lock-in packets, and low-pass filter the measured data:

        >>> from scipy.signal import firwin
        >>> coeffs = firwin(43, 80e3, fs=lck.get_df())  # low-pass filter with 80 kHz cutoff
        >>> data = lck.get_pixels(n=1000, fir_coeffs=coeffs)
        >>> freqs, (pixels_I, pixels_Q) = data[input_port]
        >>> freqs.shape
        (32,)
        >>> pixels_I.shape
        (1000, 32)
        >>> pixels_Q.shape
        (1000, 32)

        Measure 100k lock-in packets, and compute mean and standard deviation in chunks of 100
        packets:

        >>> data = lck.get_pixels(n=1000, summed=True, nsum=100)
        >>> freqs, (mean_I, std_I, mean_Q, std_Q) = data[input_port]
        >>> freqs.shape
        (32,)
        >>> mean_I.shape
        (1000, 32)
        >>> std_Q.shape
        (1000, 32)

        """
        if self.dry_run:
            raise RuntimeError("`get_pixels` does not work when `dry_run` is True")
        if self._apply_required:
            raise RuntimeError(
                "there are outstanding changes not applied to hardware. Call `apply_settings` first!"
            )

        num_pixels = int(n)

        if fir_coeffs is None:
            coeffs = np.zeros(22, np.float64)
            coeffs[-1] = 1.0
            subpixels_to_skip = 22
        else:
            # FIR filter works on sub-pixels, so it only makes sense if there's no sub-pixles
            period = int(round(self.CLK_F / self.get_df()))
            if period > 32767:
                raise NotImplementedError("FIR filter requires `df` > 15.26 kHz")

            coeffs = np.atleast_1d(fir_coeffs).astype(np.float64)
            if len(coeffs) == 22:
                # first half + center tap
                pass
            elif len(coeffs) == 43:
                # full coefficient list
                # check symmetric
                if np.any(coeffs[:21] != coeffs[-21:][::-1]):
                    raise ValueError("FIR filter must be symmetric")
                # take only the first half + center
                coeffs = coeffs[:22]
            else:
                raise ValueError("FIR filter must have 43 coefficients")
            subpixels_to_skip = 43

        # worst-case calculation (FIR acts on sub pixels)
        seconds_to_skip = subpixels_to_skip / 500_000_000 * 32767
        pixels_to_skip = int(math.ceil(seconds_to_skip * self.get_df()))

        nsum = int(nsum)
        if nsum < 1 or nsum > 1023:
            raise ValueError(f"`nsum` must be in `[1;1023]`")

        # get more pixels, and throw them away as the first pixels_to_skip are bad
        num_pixels_extra = math.ceil(pixels_to_skip / nsum) if summed else pixels_to_skip
        num_pixels_get = num_pixels + num_pixels_extra

        # two accumulators used for every quadrature I,I for direct mode I,Q for mixed mode
        lck_map = np.nonzero(self._input_used)[0].astype(np.int64).repeat(2) * 2
        lck_map[0::2] = lck_map[0::2] + 1
        lck_map = 383 - lck_map

        # number of 4-parallel lockins used, each producing 2 sums, I,I for direct mode I,Q for mixed mode
        num_demod = np.sum(self._input_used).astype(np.int64)

        self.hardware.send_command(
            cmd.LckGet, 1 if summed else 0, num_pixels_get, *coeffs, nsum, len(lck_map), *lck_map
        )

        nr_bytes = (
            8 * num_pixels * num_demod * 2
        )  # bytes/sample * num_pixels * number of used quadratures * I,Q
        nr_bytes_get = (
            8 * num_pixels_get * num_demod * 2
        )  # bytes/sample * num_pixels_get * number of used quadratures * I,Q
        if summed:
            nr_bytes *= 2  # sum and sum squared
            nr_bytes_get *= 2  # sum and sum squared
        reply = self.hardware._receive(nr_bytes_get)
        self.hardware.assert_errors()
        if not quiet:
            self.hardware.check_adc_intr_status()

        dtype = np.dtype(np.float64).newbyteorder("<")
        data = np.frombuffer(reply[-nr_bytes:], dtype=dtype)  # don't convert first bad pixels

        if summed:
            if self.adc_direct:  # summed, direct
                raise NotImplementedError("`summed=True` does not work when in `Direct` mode")

            else:  # summed, mixed
                mean1_I = data[0::4]
                mean2_I = data[1::4]
                mean1_Q = data[2::4]
                mean2_Q = data[3::4]
                # scale
                scale1 = self.get_ns(which="adc") * nsum
                scale2 = self.get_ns(which="adc") ** 2 * nsum
                mean1_I /= scale1
                mean2_I /= scale2
                mean1_Q /= scale1
                mean2_Q /= scale2
                # complex mean, can't use np.frombuffer because array is not C-contiguous
                mean1_I = mean1_I[0::2] + 1j * mean1_I[1::2]
                mean1_Q = mean1_Q[0::2] + 1j * mean1_Q[1::2]
                # real variance of complex variable
                var_Ir = mean2_I[0::2] - np.real(mean1_I) ** 2
                var_Ii = mean2_I[1::2] - np.imag(mean1_I) ** 2
                std_I = np.sqrt(var_Ir) + 1j * np.sqrt(var_Ii)
                var_Qr = mean2_Q[0::2] - np.real(mean1_Q) ** 2
                var_Qi = mean2_Q[1::2] - np.imag(mean1_Q) ** 2
                std_Q = np.sqrt(var_Qr) + 1j * np.sqrt(var_Qi)
                # reshape
                mean1_I.shape = (num_pixels, num_demod // 2)
                mean1_Q.shape = (num_pixels, num_demod // 2)
                std_I.shape = (num_pixels, num_demod // 2)
                std_Q.shape = (num_pixels, num_demod // 2)
                d = dict()
                for port, f1, l1, f2, l2 in self._input_map:
                    _mean_I = mean1_I[:, f2:l2]
                    _mean_Q = mean1_Q[:, f2:l2]
                    _std_I = std_I[:, f2:l2]
                    _std_Q = std_Q[:, f2:l2]
                    d[port] = (self._input_frequencies[f1:l1], _mean_I, _std_I, _mean_Q, _std_Q)
                return d

        else:
            # scale by lockin period
            # (conductor already scales by max amplitude)
            scale = self.get_ns(which="adc")
            data /= scale
            if self.adc_direct:  # normal, direct
                # sum I and Q samples
                data = data[0::2] + data[1::2]
                # complex
                data = np.frombuffer(data, np.complex128)
                # reshape
                data.shape = (num_pixels, num_demod // 2)
                # group inputs
                d = dict()
                for port, f1, l1, f2, l2 in self._input_map:
                    d[port] = (self._input_frequencies[f1:l1:2], data[:, f2 // 2 : l2 // 2])
                return d
            else:  # normal, mixed
                data_I, data_Q = data[0::2], data[1::2]
                # complex, can't use np.frombuffer because array is not C-contiguous
                data_I = data_I[0::2] + 1j * data_I[1::2]
                data_Q = data_Q[0::2] + 1j * data_Q[1::2]
                # reshape
                data_I.shape = (num_pixels, num_demod // 2)
                data_Q.shape = (num_pixels, num_demod // 2)
                # group inputs
                d = dict()
                for port, f1, l1, f2, l2 in self._input_map:
                    d[port] = (
                        self._input_frequencies[f1:l1:2],
                        data_I[:, f2 // 2 : l2 // 2],
                        data_Q[:, f2 // 2 : l2 // 2],
                    )
                return d

    def _first_free_output(self):
        if np.any(self._output_used):
            used = np.nonzero(self._output_used)
            last = used[0][-1] + 1
            return int(np.ceil(last / FREQ_PER_GROUP) * FREQ_PER_GROUP)
        return 0

    def _first_free_input(self):
        if np.any(self._input_used):
            used = np.nonzero(self._input_used)
            last = used[0][-1] + 1
            return int(np.ceil(last / FREQ_PER_GROUP) * FREQ_PER_GROUP)
        return 0

    def _resync_phases(self):
        if self.dac_direct:
            self._output_phases_q = (
                self._output_phases_i
                + math.tau * self._output_frequencies / self.get_fs(which="dac")
            )
        if self.adc_direct:
            self._input_phases_q = (
                self._input_phases_i
                + math.tau * self._input_frequencies / self.get_fs(which="adc")
            )
        else:
            self._input_phases_q = self._input_phases_i


class SymmetricGroup:
    """Settings of a symmetric lock-in group.

    Used as return type by :meth:`SymmetricLockin.add_symmetric_group`. Contains access functions
    for changing the settings of this input-output group.

    The lock-in output is divided into 16 groups. Each group is capable of driving tones at 12
    different frequencies, for a total of 192 frequencies. Each tone has a configurable frequency,
    phase and amplitude. Each group can be output on one or more output ports, and acquire data
    from a single (configurable) input port.

    Warning
    -------
    Do not instantiate this class directly! Call :meth:`SymmetricLockin.add_symmetric_group` to
    obtain a valid instance.
    """

    def __init__(self, input_port, output_ports, nr_freq, lockin):
        input_port = int(input_port)
        if input_port < 1 or input_port > lockin._nr_ports:
            raise ValueError(f"`port` must be in `[1, {lockin._nr_ports}]`")
        output_ports = np.atleast_1d(output_ports).astype(np.int64)
        if np.any(output_ports < 1) or np.any(output_ports > lockin._nr_ports):
            raise ValueError(f"`output_ports` must be in `[1, {lockin._nr_ports}]`")
        nr_freq = int(nr_freq)
        if nr_freq < 1 or nr_freq > NR_LCK_FREQ:
            raise ValueError(f"`nr_freq` must be in `[1, {NR_LCK_FREQ}]`")
        self.input_port = input_port
        self.output_ports = output_ports
        self.nr_freq = nr_freq
        self.lockin = lockin
        self._frequencies = np.zeros(nr_freq, np.float64)
        self._phases = np.zeros(nr_freq, np.float64)
        self._output_scales = np.zeros(nr_freq, np.float64)

    def get_frequencies(self):
        """Get the lock-in frequencies.

        Returns
        -------
        freqs : numpy.ndarray
            frequencies in Hz. `dtype` is :class:`numpy.float64`
        """
        # get every second frequency to keep same number as input frequencies
        return self._frequencies.copy()

    def set_frequencies(self, freqs) -> "SymmetricGroup":
        """Set the lock-in frequencies.

        **The new setting is not applied until** :meth:`Lockin.apply_settings` **is called!**

        Parameters
        ----------
        freqs : float or array_like
            frequency/ies in Hz. If less than available number of frequencies, the rest is set to zero.

        Notes
        -----
        This function performs no tuning, make sure `freqs` are tuned to the user needs before calling this function.

        Returns
        -------
        SymmetricGroup

        See also
        --------
        SymmetricLockin.set_df
        SymmetricLockin.tune
        """
        freqs = np.atleast_1d(np.abs(freqs)).astype(np.float64)
        if len(freqs) > self.nr_freq:
            raise ValueError(f"Group contains {self.nr_freq} tones, got {len(freqs)}")
        if np.any(freqs < 0):
            raise ValueError("`freqs` must be positive")
        max_freq = self.lockin.get_fs("dac") / 2
        if np.any(freqs >= max_freq):
            raise ValueError(f"`freqs` must be less than {max_freq/1e6} MHz")

        self.lockin._apply_required = True
        self._frequencies.fill(0)
        self._frequencies[0 : len(freqs)] = freqs

        return self

    def get_amplitudes(self):
        """Get the lock-in output amplitudes.

        Returns
        -------
        amps : numpy.ndarray
            amplitudes for each frequency with +/- 1.0 being full scale. `dtype` is :class:`numpy.float64`.
        """
        return self._output_scales.copy()

    def set_amplitudes(self, amps) -> "SymmetricGroup":
        """Set the lock-in output amplitudes.

        **The new setting is not applied until** :meth:`Lockin.apply_settings` **is called!**

        Parameters
        ----------
        amps : float or array_like
            amplitudes with +/- 1.0 being full scale. If less than available number of frequencies, set the rest to
            zero.

        Returns
        -------
        SymmetricGroup
        """
        amps = np.atleast_1d(amps).astype(np.float64)
        if len(amps) > self.nr_freq:
            raise ValueError(f"Group contains {self.nr_freq} tones, got {len(amps)}")
        if np.any(np.abs(amps) > 1.0):
            raise ValueError("Max amplitude is 1.0")

        self.lockin._apply_required = True
        self._output_scales.fill(0)
        # set every second scale to keep same number as input frequencies
        self._output_scales[0 : len(amps)] = amps

        return self

    def get_phases(self, *, deg=False):
        """Get the lock-in output phases.

        Parameters
        ----------
        deg : bool, optional
            if :obj:`True`, get the phases in degrees in `[-180.0, +180.0]`;
            if :obj:`False` (default) radians in `[-π, +π]`.

        Returns
        -------
        phases : numpy.ndarray
            phases in rad/deg for each frequency. `dtype` is :class:`numpy.float64`.
        """
        if deg:
            phases = self._phases * 180.0 / np.pi
        else:
            phases = self._phases.copy()
        return phases

    def set_phases(self, phases, *, deg=False) -> "SymmetricGroup":
        """Set the lock-in output phases.

        **The new setting is not applied until** :meth:`Lockin.apply_settings` **is called!**

        Parameters
        ----------
        phases : float or array_like
            phases in rad/deg. If less than available number of frequencies, set the rest to zero.
        deg : bool, optional
            if :obj:`True`, set the phases in degrees;
            if :obj:`False` (default) radians.

        Returns
        -------
        SymmetricGroup
        """
        phases = np.atleast_1d(phases).astype(np.float64)
        if len(phases) > self.nr_freq:
            raise ValueError(f"Group contains {self.nr_freq} tones, got {len(phases)}")

        if deg:
            phases = phases / 180.0 * np.pi

        self.lockin._apply_required = True
        self._phases.fill(0)
        self._phases[0 : len(phases)] = phases

        return self


class OutputGroup:
    """Settings of a lock-in output group.

    Used as return type by :meth:`Lockin.add_output_group`.
    Contains access functions for changing the settings of this output group.

    The lock-in output is divided into 16 groups. Each group is capable of driving tones at 12 different frequencies,
    for a total of 192 frequencies. Each tone has a configurable frequency, phase and amplitude. Each group can be
    output on one or more output ports.

    Warning
    -------
    Do not instantiate this class directly! Call :meth:`Lockin.add_output_group` to obtain a valid instance.
    """

    def __init__(self, ports, nr_freq, lockin):
        ports = np.atleast_1d(ports).astype(np.int64)
        if np.any(ports < 1) or np.any(ports > lockin._nr_ports):
            raise ValueError(f"`ports` must be in `[1, {lockin._nr_ports}]`")
        nr_freq = int(nr_freq)
        if nr_freq < 1 or nr_freq > NR_LCK_FREQ:
            raise ValueError(f"`nr_freq` must be in `[1, {NR_LCK_FREQ}]`")
        self.ports = ports
        self.nr_freq = nr_freq
        self.lockin = lockin
        self._output_frequencies = np.zeros(nr_freq, np.float64)
        self._output_phases_i = np.zeros(nr_freq, np.float64)
        self._output_phases_q = None if lockin.dac_direct else np.zeros(nr_freq, np.float64)
        self._output_scales = np.zeros(nr_freq, np.float64)

    def get_frequencies(self):
        """Get the lock-in output frequencies.

        Returns
        -------
        freqs : numpy.ndarray
            frequencies in Hz. `dtype` is :class:`numpy.float64`
        """
        # get every second frequency to keep same number as input frequencies
        return self._output_frequencies.copy()

    def set_frequencies(self, freqs) -> "OutputGroup":
        """Set the lock-in output frequencies.

        **The new setting is not applied until** :meth:`Lockin.apply_settings` **is called!**

        Parameters
        ----------
        freqs : float or array_like
            frequency/ies in Hz. If less than available number of frequencies, the rest is set to zero.

        Returns
        -------
        OutputGroup

        Notes
        -----
        This function performs no tuning, make sure `freqs` are tuned to the user needs before calling this function.

        See also
        --------
        Lockin.set_df
        Lockin.tune
        """
        freqs = np.atleast_1d(np.abs(freqs)).astype(np.float64)
        if len(freqs) > self.nr_freq:
            raise ValueError(f"Group contains {self.nr_freq} tones, got {len(freqs)}")
        if np.any(freqs < 0):
            raise ValueError("`freqs` must be positive")
        max_freq = self.lockin.get_fs("dac") / 2
        if np.any(freqs >= max_freq):
            raise ValueError(f"`freqs` must be less than {max_freq/1e6} MHz")

        self.lockin._apply_required = True
        self._output_frequencies.fill(0)
        self._output_frequencies[0 : len(freqs)] = freqs

        return self

    def get_amplitudes(self):
        """Get the lock-in output amplitudes.

        Returns
        -------
        amps : numpy.ndarray
            amplitudes for each frequency with +/- 1.0 being full scale. `dtype` is :class:`numpy.float64`.
        """
        # get every second scale to keep same number as input frequencies
        return self._output_scales.copy()

    def set_amplitudes(self, amps) -> "OutputGroup":
        """Set the lock-in output amplitudes.

        **The new setting is not applied until** :meth:`Lockin.apply_settings` **is called!**

        Parameters
        ----------
        amps : float or array_like
            amplitudes with +/- 1.0 being full scale. If less than available number of frequencies, set the rest to
            zero.

        Returns
        -------
        OutputGroup
        """
        amps = np.atleast_1d(amps).astype(np.float64)
        if len(amps) > self.nr_freq:
            raise ValueError(f"Group contains {self.nr_freq} tones, got {len(amps)}")
        if np.any(np.abs(amps) > 1.0):
            raise ValueError("Max amplitude is 1.0")

        self.lockin._apply_required = True
        self._output_scales.fill(0)
        # set every second scale to keep same number as input frequencies
        self._output_scales[0 : len(amps)] = amps

        return self

    def get_phases(self, *, deg=False):
        """Get the lock-in output phases.

        Parameters
        ----------
        deg : bool, optional
            if :obj:`True`, get the phases in degrees in `[-180.0, +180.0]`;
            if :obj:`False` (default) radians in `[-π, +π]`.

        Returns
        -------
        phases : numpy.ndarray
            phases in rad/deg for each frequency. `dtype` is :class:`numpy.float64`.
        """
        if deg:
            phases = self._output_phases_i * 180.0 / np.pi
        else:
            phases = self._output_phases_i.copy()
        # get every second phase to keep same number as input frequencies
        return phases

    def set_phases(self, phases, phases_q=None, *, deg=False) -> "OutputGroup":
        """Set the lock-in output phases.

        **The new setting is not applied until** :meth:`Lockin.apply_settings` **is called!**

        Parameters
        ----------
        phases : float or array_like
            phases in rad/deg. If less than available number of frequencies, set the rest to zero. When using
            the digital mixers (`dac_mode` is one of :class:`DacMode.Mixedxx <presto.hardware.DacMode>`), sets the
            phase of the I port of the upconversion mixer.
        phases_q : float or array_like, optional
            when using the digital mixers, sets the phase of the Q port of the upconversion mixer. In direct mode
            (`dac_mode` is :class:`DacMode.Direct <presto.hardware.DacMode>`), setting `phases_q` throws a
            :class:`ValueError` exception.
        deg : bool, optional
            if :obj:`True`, set the phases in degrees;
            if :obj:`False` (default) radians.

        Returns
        -------
        OutputGroup
        """
        phases = np.atleast_1d(phases).astype(np.float64)
        if len(phases) > self.nr_freq:
            raise ValueError(f"Group contains {self.nr_freq} tones, got {len(phases)}")
        if self.lockin.dac_direct:
            if phases_q is not None:
                raise ValueError("setting `phases_q` is not allowed if `dac_mode` is `DacDirect`!")
        else:
            if phases_q is None:
                raise ValueError("must provide `phases_q` if `dac_mode` is not `DacDirect`!")
            phases_q = np.atleast_1d(phases_q).astype(np.float64)
            if phases_q.shape != phases.shape:
                raise ValueError("`phases_q` must have same shape as `phases`!")

        if deg:
            phases = phases / 180.0 * np.pi

        self.lockin._apply_required = True
        self._output_phases_i.fill(0)
        self._output_phases_i[0 : len(phases)] = phases

        if self.lockin.dac_direct:
            pass
        else:
            assert self._output_phases_q is not None
            self._output_phases_q.fill(0)
            self._output_phases_q[0 : len(phases_q)] = phases_q

        return self


class InputGroup:
    """Settings of a lock-in input group.

    Used as return type by :meth:`Lockin.add_input_group`.
    Contains access functions for changing the settings of this input group.

    The lock-in input is divided into 16 groups. Each group is capable of demodulating 12 different quadratures, for a
    total of 192 demodulations (96 I/Q pairs). Each demodulator has a configurable frequency and phase. Each group can
    acquire data from a single (configurable) input port.

    Warning
    -------
    Do not instantiate this class directly! Call :meth:`Lockin.add_input_group` to obtain a valid instance.
    """

    def __init__(self, port, nr_freq, lockin):
        port = int(port)
        if port < 1 or port > lockin._nr_ports:
            raise ValueError(f"`port` must be in `[1, {lockin._nr_ports}]`")
        nr_freq = int(nr_freq)
        # TODO: fix check? we might already check when creating the instance from Lockin
        # if VARIANT == 7 and (nr_freq < 1 or nr_freq > NR_LCK_FREQ // 2):
        #     raise ValueError(f"`nr_freq` must be in `[1, {NR_LCK_FREQ//2}]`")
        # if VARIANT == 8 and (nr_freq < 1 or nr_freq > NR_LCK_FREQ):
        #     raise ValueError(f"`nr_freq` must be in `[1, {NR_LCK_FREQ}]`")
        self.port = port
        self.nr_freq = nr_freq
        self.lockin = lockin
        self._input_frequencies = np.zeros(nr_freq, np.float64)
        self._input_phases_i = np.zeros(nr_freq, np.float64)

    def get_frequencies(self):
        """Get the lock-in input frequencies.

        Returns
        -------
        freqs : numpy.ndarray
            frequencies in Hz. `dtype` is :class:`numpy.float64`
        """
        # get every second frequency to since every frequency is replicated for I and Q
        return self._input_frequencies.copy()

    def set_frequencies(self, freqs) -> "InputGroup":
        """Set the lock-in input frequencies.

        **The new setting is not applied until** :meth:`Lockin.apply_settings` **is called!**

        Parameters
        ----------
        freqs : float or array_like
            frequency/ies in Hz. If less than available number of frequencies, the rest is set to zero.

        Returns
        -------
        InputGroup

        Notes
        -----
        This function performs no tuning, make sure `freqs` are tuned to the user needs before calling this function.

        See also
        --------
        Lockin.set_df
        Lockin.tune
        """
        freqs = np.atleast_1d(np.abs(freqs)).astype(np.float64)
        if len(freqs) > self.nr_freq:
            raise ValueError(f"Group contains {self.nr_freq} tones, got {len(freqs)}")
        if np.any(freqs < 0):
            raise ValueError("`freqs` must be positive")
        max_freq = self.lockin.get_fs("adc") / 2
        if np.any(freqs >= max_freq):
            raise ValueError(f"`freqs` must be less than {max_freq/1e6} MHz")

        self.lockin._apply_required = True
        self._input_frequencies.fill(0)
        self._input_frequencies[: len(freqs)] = freqs

        return self

    def get_phases(self, *, deg=False):
        """Get the lock-in input phases.

        Parameters
        ----------
        deg : bool, optional
            if :obj:`True`, get the phases in degrees in `[-180.0, +180.0]`;
            if :obj:`False` (default) radians in `[-π, +π]`.

        Returns
        -------
        phases : numpy.ndarray
            phases in rad/deg for each frequency. `dtype` is :class:`numpy.float64`.
        """
        if deg:
            phases = self._input_phases_i * 180.0 / np.pi
        else:
            phases = self._input_phases_i.copy()
        # get every second phase to keep same number as input frequencies
        return phases

    def set_phases(self, phases, *, deg=False) -> "InputGroup":
        """Set the lock-in input phases.

        **The new setting is not applied until** :meth:`Lockin.apply_settings` **is called!**

        Parameters
        ----------
        phases : float or array_like
            phases in rad/deg. If less than available number of frequencies, set the rest to zero. When using the
            digital mixers (`adc_mode` is :class:`AdcMode.Mixed <presto.hardware.AdcMode>`), sets the phase of both the
            I and the Q port of the downconversion mixer.
        deg : bool, optional
            if :obj:`True`, set the phases in degrees;
            if :obj:`False` (default) radians.

        Returns
        -------
        InputGroup
        """
        phases = np.atleast_1d(phases).astype(np.float64)
        if len(phases) > self.nr_freq:
            raise ValueError(f"Group contains {self.nr_freq} tones, got {len(phases)}")

        if deg:
            phases = phases / 180.0 * np.pi

        self.lockin._apply_required = True
        self._input_phases_i.fill(0)
        self._input_phases_i = phases

        return self


# where not obvious, changes from Lockin are marked with NOTE
class SymmetricLockin(Lockin):
    VARIANT = 8

    def __init__(
        self,
        *,
        ext_ref_clk=False,
        force_reload=False,
        dry_run=False,
        address=None,
        port=None,
        adc_mode=AdcMode.Mixed,
        adc_fsample=AdcFSample.G2,
        dac_mode=DacMode.Mixed02,
        dac_fsample=DacFSample.G4,
        force_config=False,
    ):
        r"""Special-purpose version of :class:`Lockin` with same frequencies on input and output (symmetric).

        The symmetric lock-in only supports :ref:`Mixed mode <converter modes>`. The digital mixers
        are configured for single-sideband upconversion and downconversion, using the upper
        sideband. The frequency of the output tones will therefore be the sum of the IF frequency
        set with :meth:`set_frequencies <SymmetricGroup.set_frequencies>` and of the LO frequency
        set with :meth:`hardware.configure_mixer <presto.hardware.Hardware.configure_mixer>`.

        Warnings
        --------
        Create only one instance at a time. This class is designed to be instantiated with Python's :ref:`with
        statement <python:with>`, see Examples section.

        Parameters
        ----------
        ext_ref_clk : optional
            if :obj:`None` or :obj:`False` use internal reference clock; if :obj:`True` use external reference clock
            (10 MHz); if :class:`float` or :class:`int` use external reference clock at `ext_ref_clk` Hz
        force_reload : bool, optional
            if :obj:`True` re-configure clock and reload firmware even if there's no change from the previous settings.
        dry_run : bool, optional
            if :obj:`False` don't connect to hardware, for testing only.
        address : str, optional
            IP address or hostname of the hardware. If :obj:`None`, use factory default `"192.168.42.50"`.
        port : int, optional
            port number of the server running on the hardware. If :obj:`None`, use factory default `7878`.
        adc_mode : hardware.AdcMode or list, optional
            configure the inputs to use the digital mixers for downconversion. Direct mode is not supported.
        adc_fsample : hardware.AdcFSample or list, optional
            configure the inputs sampling rate (default 2 GS/s). See Notes.
        dac_mode : hardware.DacMode or list, optional
            configure the outputs to use the digital mixers for upconversion. Direct mode is not
            supported. See Notes.
        dac_fsample : hardware.DacFSample or list, optional
            configure the outputs sampling rate (default 4 GS/s). See Notes.
        force_config : bool, optional
            if :obj:`True` skip checks on `DacMode`\ s not recommended for high DAC sampling rates.

        Raises
        ------
        ValueError
            if `adc_mode` or `dac_mode` are not valid :ref:`converter modes`;
            if `adc_fsample` or `dac_fsample` are not valid :ref:`converter rates`.

        Notes
        -----
        In all the Examples, it is assumed that the imports ``import numpy as np`` and ``from presto import lockin``
        have been performed, and that this class has been instantiated in the form ``lck = lockin.SymmetricLockin()``, or,
        **much much better**, using the ``with lockin.SymmetricLockin() as lck`` construct as below.

        For valid values of `adc_mode` and `dac_mode`, see :ref:`converter modes`. For valid values of `adc_fsample`
        and `dac_fsample`, see :ref:`converter rates`. For advanced configuration, e.g. different converter rates on
        different ports, see :ref:`adv tile`.

        """
        modes = as_flat_list(adc_mode)
        modes.extend(as_flat_list(dac_mode))
        for mode in modes:
            if mode is AdcMode.Direct or mode is DacMode.Direct:
                raise ValueError("`SymmetricLockin only works with ADCs and DACs in Mixed mode`")
        super().__init__(
            ext_ref_clk=ext_ref_clk,
            force_reload=force_reload,
            dry_run=dry_run,
            address=address,
            port=port,
            adc_mode=adc_mode,
            adc_fsample=adc_fsample,
            dac_mode=dac_mode,
            dac_fsample=dac_fsample,
            force_config=force_config,
        )

    def check_current_consumption(self):
        # TODO
        pass

    def apply_settings(self):
        """Apply the settings to the hardware.

        Notes
        -----
        Prior to a call to this function, any change of settings has no effect on the hardware.
        """
        self._clear_outputs()
        self._clear_inputs()

        for sg in self._output_groups:
            assert isinstance(sg, SymmetricGroup)
            self._add_output(
                sg.output_ports, sg._frequencies, sg._output_scales, sg._phases, sg._phases
            )
        for sg in self._input_groups:
            assert isinstance(sg, SymmetricGroup)
            self._add_input(sg.input_port, sg._frequencies, sg._phases)

        self.check_current_consumption()

        if not self.dry_run:
            # disable outputs
            self.hardware.blank_output(range(1, self._nr_ports + 1), True)

            # correct for latencies within one group
            idx_in_group = np.arange(len(self._input_phases_i)) % FREQ_PER_GROUP
            correction = idx_in_group * self.CLK_T * 2 * np.pi * self._input_frequencies
            input_phases_i = self._input_phases_i - correction
            input_phases_q = self._input_phases_q - correction
            # send settings
            self.hardware.send_command(
                cmd.LckSetInFreqPhase,
                len(self._input_frequencies),
                *self._input_frequencies,
                *input_phases_i,
                *input_phases_q,
            )
            # NOTE: there's no output phases in SymmetricLockin

            self.hardware.send_command(
                cmd.LckSetScale, len(self._output_scales), *self._output_scales
            )
            self.hardware.send_command(
                cmd.LckSetDf,
                self.get_df(),
                1 if self._reset_phase else 0,
                self._trigctrl,
                self._trigstart,
                self._trigstart + self._trigwidth,
            )

            for channel in range(self._nr_ports):
                self.hardware.send_command(cmd.LckGroupMask, channel, self._output_mask[channel])

            for i in range(NR_GROUPS):
                self.hardware.send_command(cmd.LckInputSelect, i, self._input_select[i])

            # enable outputs
            self.hardware.sleep(self.get_Tm(), False)
            self.hardware.blank_output(range(1, self._nr_ports + 1), False)

            self.hardware.assert_errors()
        self._apply_required = False

    def _add_input(self, port, freqs, phases):
        """
        Parameters
        ----------
        port  : int
        freqs : int or array_like
        """
        if port in [x[0] for x in self._input_map]:
            raise ValueError("Can only add an input once")

        freqs = np.atleast_1d(np.abs(freqs)).astype(np.float64)
        # NOTE: not doubling the frequencies

        first = self._first_free_input()
        last = first + freqs.shape[0]

        if last > NR_LCK_FREQ:
            raise ValueError("Too many input frequencies used")

        self._input_frequencies[first:last] = freqs
        self._input_phases_i[first:last] = phases  # NOTE: not setting different phases on Q
        for i in set(np.arange(first, last, dtype=np.int64) // FREQ_PER_GROUP):
            self._input_select[i] = port - 1
        self._input_used[first:last] = True
        if len(self._input_map) == 0:
            self._input_map.append((port, first, last, first, last))
        else:
            tot_used = self._input_map[-1][4]
            self._input_map.append((port, first, last, tot_used, tot_used + (last - first)))

        self._resync_phases()

    def add_input_group(self, port, nr_freq) -> InputGroup:
        """"""  # hide in documentation
        raise NotImplementedError("use `add_symmetric_group` instead")

    def add_output_group(self, ports, nr_freq) -> OutputGroup:
        """"""  # hide in documentation
        raise NotImplementedError("use `add_symmetric_group` instead")

    def add_symmetric_group(self, input_port, output_ports, nr_freq) -> SymmetricGroup:
        """Create and return a new :class:`symmetric group <presto.lockin.Symmetric>`

        Parameters
        ----------
        input_port : int
            which input port the group should sample data from
        output_ports : int or list of int
            which output port(s) the group should output data to. If a :class:`list`, the output
            will be replicated on all `ports`
        nr_freq : int
            how many frequencies the input group should modulate/demodulate

        Returns
        -------
        SymmetricGroup
        """
        g = SymmetricGroup(input_port, output_ports, nr_freq, self)
        self._input_groups.append(g)
        self._output_groups.append(g)
        self._add_input(input_port, np.zeros(nr_freq), np.zeros(nr_freq))
        self._add_output(
            output_ports,
            np.zeros(nr_freq),
            np.zeros(nr_freq),
            np.zeros(nr_freq),
            np.zeros(nr_freq),
        )
        return g

    def _resync_phases(self):
        # NOTE: no direct case
        self._input_phases_q = self._input_phases_i - np.pi / 2  # NOTE: add phase to Q for HSB

    def get_pixels(
        self,
        n,
        summed: bool = False,
        fir_coeffs: Optional[List[float]] = None,
        nsum: int = 250,
        quiet: bool = False,
    ) -> dict:
        r"""Get lock-in packets (pixels) from the hardware.

        Parameters
        ----------
        n : int
            the number of lock-in packets to measure. When `summed=True`, `n` is the number of
            means and standard deviation acquired: the number of lock-in packets measured will be
            `n*nsum`.
        summed : bool, optional
            when `True`, calculate on the hardware the mean and standard deviation of the acquired
            data in chunks of `nsum` lock-in packets.
        fir_coeffs : list of float, optional
            coefficients for FIR filter to be applied to measured data. 43 coefficients must be
            provided, or pass None (default) to disable the filter. See also *Notes* and *Examples*
            sections.
        nsum : int, optional
            ignored if `summed=False`. How many lock-in packets (at rate :meth:`get_df`\ ) The
            resulting data rate will be :meth:`get_df`\ `/ nsum`.
        quiet
            if True, don't check for inputs out of range

        Returns
        -------
        pixels : :class:`dict`
            dictionary with key `port` and value depending on the value of `summed`.

            The key is always:

            * `port` (:class:`int`): input port measured

            When `summed=False` (default), the value is a tuple of:

            * `freqs` (:class:`np.ndarray <numpy.ndarray>`, `dtype=np.float64`): frequencies at
              which the lockin measurement was done.
            * `pixels` (:class:`np.ndarray <numpy.ndarray>`, `dtype=np.complex128`): measured
              lock-in data in ratio of full-scale input. `shape` is `(n, len(freqs))`.

            When `summed=True`, the value is a tuple of:

            * `freqs` (:class:`np.ndarray <numpy.ndarray>`, `dtype=np.float64`): frequencies at
              which the lockin measurement was done.
            * `mean` (:class:`np.ndarray <numpy.ndarray>`, `dtype=np.complex128`): calculated mean
              of `nsum` consecutive lock-in packets. `shape` is `(n, len(freqs))`.
            * `std` (:class:`np.ndarray <numpy.ndarray>`, `dtype=np.complex128`): calculated
              standard deviation of `nsum` consecutive lock-in packets. `shape` is `(n,
              len(freqs))`. The standard deviation has a real and an imaginary part; `abs(std)` is
              the total standard deviation according to `Complex random variable
              <https://en.wikipedia.org/wiki/Complex_random_variable#Variance_and_pseudo-variance>`_.

        Raises
        ------
        RuntimeError
            if :meth:`apply_settings` was not called after changing some setting

        Notes
        -----
        This method locks execution until at least `n` measured packets are available.

        Useful functions for computing the coefficients `fir_coeffs` for the FIR filter are
        :func:`remez <scipy.signal.remez>` and :func:`firwin <scipy.signal.firwin>` in the
        :mod:`scipy.signal` module.

        Examples
        --------
        Measure 1k lock-in packets, and low-pass filter the measured data:

        >>> from scipy.signal import firwin
        >>> coeffs = firwin(43, 80e3, fs=lck.get_df())  # low-pass filter with 80 kHz cutoff
        >>> data = lck.get_pixels(n=1000, fir_coeffs=coeffs)
        >>> freqs, pixels = data[input_port]
        >>> freqs.shape
        (32,)
        >>> pixels.shape
        (1000, 32)

        Measure 100k lock-in packets, and compute mean and standard deviation in chunks of 100
        packets:

        >>> data = lck.get_pixels(n=1000, summed=True, nsum=100)
        >>> freqs, mean, std = data[input_port]
        >>> freqs.shape
        (32,)
        >>> mean.shape
        (1000, 32)
        >>> std.shape
        (1000, 32)

        """
        if self.dry_run:
            raise RuntimeError("`get_pixels` does not work when `dry_run` is True")
        if self._apply_required:
            raise RuntimeError(
                "there are outstanding changes not applied to hardware. Call `apply_settings` first!"
            )

        num_pixels = int(n)

        if fir_coeffs is None:
            coeffs = np.zeros(22, np.float64)
            coeffs[-1] = 1.0
            subpixels_to_skip = 22
        else:
            # FIR filter works on sub-pixels, so it only makes sense if there's no sub-pixles
            period = int(round(self.CLK_F / self.get_df()))
            if period > 32767:
                raise NotImplementedError("FIR filter requires `df` > 15.26 kHz")

            coeffs = np.atleast_1d(fir_coeffs).astype(np.float64)
            if len(coeffs) == 22:
                # first half + center tap
                pass
            elif len(coeffs) == 43:
                # full coefficient list
                # check symmetric
                if not np.allclose(coeffs[:21], coeffs[-21:][::-1]):
                    raise ValueError("FIR filter must be symmetric")
                # take only the first half + center
                coeffs = coeffs[:22]
            else:
                raise ValueError("FIR filter must have 43 coefficients")
            subpixels_to_skip = 43

        # worst-case calculation (FIR acts on sub pixels)
        seconds_to_skip = subpixels_to_skip / 500_000_000 * 32767
        pixels_to_skip = int(math.ceil(seconds_to_skip * self.get_df()))

        nsum = int(nsum)
        if nsum < 1 or nsum > 1023:
            raise ValueError(f"`nsum` must be in `[1;1023]`")

        # get more pixels, and throw them away as the first pixels_to_skip are bad
        num_pixels_extra = math.ceil(pixels_to_skip / nsum) if summed else pixels_to_skip
        num_pixels_get = num_pixels + num_pixels_extra

        # two accumulators used for every quadrature I,I for direct mode I,Q for mixed mode
        lck_map = np.nonzero(self._input_used)[0].astype(np.int64).repeat(2) * 2
        lck_map[0::2] = lck_map[0::2] + 1
        lck_map = 383 - lck_map

        # number of 4-parallel lockins used, each producing 2 sums, I,I for direct mode I,Q for mixed mode
        num_demod = np.sum(self._input_used).astype(np.int64)

        self.hardware.send_command(
            cmd.LckGet, 1 if summed else 0, num_pixels_get, *coeffs, nsum, len(lck_map), *lck_map
        )

        nr_bytes = (
            8 * num_pixels * num_demod * 2
        )  # bytes/sample * num_pixels * number of used quadratures * I,Q
        nr_bytes_get = (
            8 * num_pixels_get * num_demod * 2
        )  # bytes/sample * num_pixels_get * number of used quadratures * I,Q
        if summed:
            nr_bytes *= 2  # sum and sum squared
            nr_bytes_get *= 2  # sum and sum squared
        reply = self.hardware._receive(nr_bytes_get)
        self.hardware.assert_errors()
        if not quiet:
            self.hardware.check_adc_intr_status()

        dtype = np.dtype(np.float64).newbyteorder("<")
        data = np.frombuffer(reply[-nr_bytes:], dtype=dtype)

        if summed:
            # NOTE: no direct case
            mean1_I = data[0::4]
            mean2_I = data[1::4]
            mean1_Q = data[2::4]
            mean2_Q = data[3::4]
            scale1 = self.get_ns(which="adc") * nsum / 2  # /2 to account for SSB
            scale2 = self.get_ns(which="adc") ** 2 * nsum / 4  # /4 to account for SSB
            mean1_I /= scale1
            mean2_I /= scale2
            mean1_Q /= scale1
            mean2_Q /= scale2

            mean1_I.shape = (num_pixels, num_demod)
            mean1_Q.shape = (num_pixels, num_demod)
            mean2_I.shape = (num_pixels, num_demod)
            mean2_Q.shape = (num_pixels, num_demod)
            d = dict()
            for port, f1, l1, f2, l2 in self._input_map:
                rotation_phases = (
                    -(np.arange(f1, l1) % FREQ_PER_GROUP)
                    * self.CLK_T
                    * 2
                    * np.pi
                    * self._input_frequencies[f1:l1]
                )
                mean1_C = (
                    mean1_I[:, f2:l2] + 1j * mean1_Q[:, f2:l2]
                )  # assume SSB, fine both HSB and LSB
                mean1_C *= np.exp(1j * rotation_phases)
                varI = mean2_I[:, f2:l2] - mean1_I[:, f2:l2] ** 2
                varQ = mean2_Q[:, f2:l2] - mean1_Q[:, f2:l2] ** 2
                std = np.sqrt(varI) + 1j * np.sqrt(varQ)
                d[port] = (self._input_frequencies[f1:l1], mean1_C, std)
            return d

        else:
            # NOTE: no direct case
            scale = (
                self.get_ns(which="adc") / 2
            )  # scale by lockin period  (conductor already scales by max amplitude), /2 to account for SSB
            data /= scale
            data_C = np.frombuffer(data, dtype=np.complex128)
            # reshape
            data_C.shape = (num_pixels, num_demod)
            # group inputs
            d = dict()
            for port, f1, l1, f2, l2 in self._input_map:
                rotation_phases = (
                    -(np.arange(f1, l1) % FREQ_PER_GROUP)
                    * self.CLK_T
                    * 2
                    * np.pi
                    * self._input_frequencies[f1:l1]
                )
                data_group = data_C[:, f2:l2]
                data_group *= np.exp(1j * rotation_phases)
                d[port] = (
                    self._input_frequencies[f1:l1],
                    data_group,
                )
            return d
