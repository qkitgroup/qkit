# Copyright (C) Intermodulation Products AB, 2018 - All Rights Reserved.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential. Please refer to file LICENSE for details.
"""Collection of functions that might be useful, or might not."""

from datetime import timedelta
import os
import shutil
import sys
import time
from typing import List, Tuple, Union

import numpy as np


def _ssh_connect(address: str = "192.168.42.50", **kwargs):
    """Connect to the hardware using SSH.

    Args:
        address: IP address or hostname of the hardware.
        kwargs: Extra arguments are passed directly to :class:`fabric.connection.Connection`.

    Returns:
        Handle to the connection.

    Raises:
        ImportError: Python module `fabric` not found.
    """
    import fabric

    key_filename = os.path.join(os.path.dirname(__file__), "id_rsa_alice")
    arguments = {
        "host": str(address),
        "user": "alice",
        "connect_kwargs": {
            "key_filename": [key_filename],
            "allow_agent": False,
            "look_for_keys": False,
        },
    }
    arguments.update(kwargs)
    connection = fabric.Connection(**arguments)

    return connection


def ssh_execute(command: str, address: str = "192.168.42.50"):
    """Execute a command on the hardware.

    Args:
        command
        address: IP address or hostname of the hardware.

    Raises:
        ImportError: Python module `fabric` not found.
    """
    with _ssh_connect(address=address) as c:
        res = c.run(command)
    return res


def ssh_reboot(address: str = "192.168.42.50"):
    """Reboot the Linux system on the hardware.

    It is equivalent to `ssh_execute("/sbin/shutdown -r now")`.

    Args:
        address: IP address or hostname of the hardware

    Raises:
        ImportError: Python module `fabric` not found.
    """
    return ssh_execute(
        command="sudo /sbin/shutdown -r now || /sbin/shutdown -r now", address=address
    )


def ssh_upload(local_filename: str, remote_filename: str = None, address: str = "192.168.42.50"):
    """Copy a file from the local computer to the hardware.

    Args:
        local_filename
        remote_filename
        address: IP address or hostname of the hardware.

    Raises:
        ImportError: Python module `fabric` not found.
    """
    with _ssh_connect(address=address) as c:
        res = c.put(local_filename, remote_filename)
    return res


def ssh_download(remote_filename: str, local_filename: str = None, address: str = "192.168.42.50"):
    """Copy a file from the hardware to the local computer.

    Args:
        remote_filename
        local_filename
        address: IP address or hostname of the hardware.

    Raises:
        ImportError: Python module `fabric` not found.
    """
    with _ssh_connect(address=address) as c:
        res = c.get(remote_filename, local_filename)
    return res


def format_sec(s: Union[float, timedelta]) -> str:
    """Format a time interval in seconds into a more human-readable string.

    Args:
    s: time interval in seconds.

    Returns:
        time interval in the form "Xh Ym Z.zs".

    Examples:
        >>> format_sec(np.pi * 1e+8)
        '9y 348d 20h 27m 45.4s'
        >>> format_sec(np.exp(-10))
        '45.4us'
    """
    if isinstance(s, timedelta):
        s = s.total_seconds()

    if s < 0.0:
        sign = "-"
        s = -s
    else:
        sign = ""

    if s < 1e-24:
        ret = "{:.1e}".format(s)

    elif s < 1.0:
        if s < 1e-21:
            scale = 1e24
            unit = "ys"
        elif s < 1e-18:
            scale = 1e21
            unit = "zs"
        elif s < 1e-15:
            scale = 1e18
            unit = "as"
        elif s < 1e-12:
            scale = 1e15
            unit = "fs"
        elif s < 1e-9:
            scale = 1e12
            unit = "ps"
        elif s < 1e-6:
            scale = 1e9
            unit = "ns"
        elif s < 1e-3:
            scale = 1e6
            unit = "us"
        else:
            scale = 1e3
            unit = "ms"
        ret = "{:.1f}{:s}".format(s * scale, unit)

    else:
        y = int(s // 31_557_600)
        s -= y * 31_557_600.0

        d = int(s // 86_400)
        s -= d * 86_400.0

        h = int(s // 3_600)
        s -= h * 3_600.0

        m = int(s // 60)
        s -= m * 60.0

        if y:
            ret = "{:d}y {:d}d {:d}h {:d}m {:.1f}s".format(y, d, h, m, s)
        elif d:
            ret = "{:d}d {:d}h {:d}m {:.1f}s".format(d, h, m, s)
        elif h:
            ret = "{:d}h {:d}m {:.1f}s".format(h, m, s)
        elif m:
            ret = "{:d}m {:.1f}s".format(m, s)
        else:
            ret = "{:.1f}s".format(s)

    return sign + ret


def format_precision(n: float, s: float) -> str:
    """Format a value and uncertainty to the correct number of significant digits.

    Args:
        n: nominal value.
        s: uncertainty.

    Returns:
        a formatted string with numbers rounded to significant digits.

    Examples:
        >>> format_precision(36.91226461435421, 0.4060358649863922)
        '36.9 ± 0.4'
    """
    digits = -int(np.floor(np.log10(s)))
    n = round(n, digits)
    s = round(s, digits)
    return f"{n} ± {s}"


def eprint(*objects):
    print(*objects, file=sys.stderr)


def _colored(aec: str, msg: str) -> str:
    return "{}{}{}".format(aec, msg, _AEC_RESET)


def eprint_error(title: str, body: str, warn: bool = False, inline: bool = False):
    aec = _AEC_YELLOW if warn else _AEC_RED
    if not title:
        eprint(_colored(aec, body))
    else:
        if inline:
            wide = f"{title}:"
            eprint("{} {}".format(_colored(aec, wide), body))
        else:
            wide = f" {title} "
            eprint(_colored(aec, f"{wide:-^80}"))
            eprint(body)
            eprint(_colored(aec, f"{'':-^80}"))


def get_sourcecode(script_filename: str) -> List[str]:
    """Open a file and return its content.

    Args:
        script_filename: path to the file.

    Returns:
        the lines of the file at `script_filename`.
    """
    with open(script_filename, mode="rt", encoding="utf-8") as f:
        sourcecode = f.readlines()
    return sourcecode


def untwist_downconversion(
    I_port: np.ndarray, Q_port: np.ndarray
) -> Tuple[np.ndarray, np.ndarray]:
    """Convert a measured IQ pair into a low/high sideband pair.

    Args:
        I_port: `dtype=complex128`
        Q_port: `dtype=complex128`

    Returns:
        a tuple (L_sideband, H_sideband) of NumPy arrays with `dtype=complex128`.
    """
    L_sideband = np.zeros_like(I_port)
    H_sideband = np.zeros_like(Q_port)

    L_sideband.real += I_port.real + Q_port.imag
    L_sideband.imag += Q_port.real - I_port.imag
    H_sideband.real += I_port.real - Q_port.imag
    H_sideband.imag += Q_port.real + I_port.imag

    return L_sideband, H_sideband


def sin2(nr_samples: int, drag: float = 0.0) -> np.ndarray:
    r"""Create a :math:`\sin^2` envelope/template.

    Args:
        nr_samples
        drag: if nonzero, use DRAG with :math:`\lambda / \alpha` equal to `drag`

    Returns:
        NumPy array for desired pulse with `dtype=float64` if `drag=0.0`, or `dtype=complex128` otherwise.
    """
    x = np.linspace(0.0, 1.0, nr_samples, endpoint=False)
    if drag == 0.0:
        return np.sin(np.pi * x) ** 2
    else:
        ret = np.zeros_like(x, np.complex128)
        ret.real = np.sin(np.pi * x) ** 2
        # NOTE: assume 1 GS/s sampling rate
        ret.imag = drag * np.pi * np.sin(2 * np.pi * x) / (nr_samples * 1e-9)
        return ret


def sinP(P: float, nr_samples: int) -> np.ndarray:
    r"""Create a :math:`\sin^P` envelope/template.

    Args:
        P
        nr_samples

    Returns:
        NumPy array for desired pulse with `dtype=float64`.
    """
    x = np.linspace(0.0, 1.0, nr_samples, endpoint=False)
    return np.sin(np.pi * x) ** P


def triangle(nr_samples: int) -> np.ndarray:
    """Create a triangular envelope/template.

    Args:
        nr_samples

    Returns:
        NumPy array for desired pulse with `dtype=float64`.
    """
    t1 = np.linspace(0.0, 1.0, nr_samples // 2, endpoint=False)
    t2 = np.linspace(1.0, 0.0, nr_samples // 2, endpoint=False)
    return np.concatenate((t1, t2))


def _flatten(li):
    return sum(
        ([x] if not isinstance(x, (list, tuple, np.ndarray)) else _flatten(x) for x in li), []
    )


def as_flat_list(x: object) -> list:
    """Return `x` as a flat unidimensional list.

    Args:
        x: An arbitrarily nested list, tuple, np.ndarray, or a mixture thereof.

    Returns:
        A flat, unidimensional list with all the objects of `x`.
    """
    li = [x]
    return _flatten(li)


def rotate_opt(data: np.ndarray, return_x: bool = False) -> np.ndarray:
    """Rotates `data` so that all the signal is in the I quadrature (real part).

    Args:
        data: `dtype` should be `complex128`.
        return_x: if :obj:`True`, return also the angle by which `data` was rotated.

    Returns:
        `data * np.exp(1j * x)`, with `x` such that `np.std(ret.imag)` is minimum. `dtype=complex128`.

        If `return_x=True`, also return the angle `x`.
    """
    # calculate the variance in steps of 1 deg
    N = 360
    _var = np.zeros(N)
    for ii in range(N):
        _data = data * np.exp(1j * 2 * np.pi / N * ii)
        _var[ii] = np.var(_data.imag)

    # the variance goes like cos(x)**2
    # FFT and find the phase at frequency "2"
    fft = np.fft.rfft(_var) / N
    # first solution
    x_fft1 = -np.angle(fft[2])  # compensate for measured phase
    x_fft1 -= np.pi  # we want to be at the minimum of cos(2x)
    x_fft1 /= 2  # move from frequency "2" to "1"
    # there's a second solution np.pi away (a minus sign)
    x_fft2 = x_fft1 + np.pi

    # convert to +/- interval
    x_fft1 = to_pm_pi(x_fft1)
    x_fft2 = to_pm_pi(x_fft2)
    # choose the closest to zero
    if np.abs(x_fft1) < np.abs(x_fft2):
        x_fft = x_fft1
    else:
        x_fft = x_fft2

    # rotate the data and return a copy
    data = data * np.exp(1j * x_fft)
    if return_x:
        return data, x_fft
    else:
        return data


def to_pm_pi(phase: float) -> float:
    """Converts a phase in radians into the [-π, +π) interval.

    Args:
        phase
    """
    return (phase + np.pi) % (2 * np.pi) - np.pi


class ProgressBar:
    """Prints a progress bar to stderr, keeping track of remaining time.

    Arguments
    ---------
    size : int
        how many \"units of work\" will be done
    update_time : float, optional
        limit the update of the progress bar to `update_time` seconds

    Examples
    --------
    >>> pb = ProgressBar(100)
    >>> pb.start()
    >>> for _ in range(100):
    >>>     time.sleep(0.1)  # <-- do work here!
    >>>     pb.increment()
    >>> pb.done()
    """

    def __init__(self, size: int, update_time: float = 1.0) -> None:
        self.size: int = size
        self.status: int = 0
        self.start_time: float = 0.0
        self.last_len: int = 0
        self.update_time: float = update_time
        self.last_time: float = 0.0
        self.bar_size = self._calculate_bar_size()

    def _calculate_bar_size(self) -> int:
        max_bar = shutil.get_terminal_size().columns
        # max_bar -= 2  # "[]"
        # max_bar -= 12 # " Remaining: "
        return max_bar // 2 - 2

    def start(self) -> None:
        """Start counting time."""
        self.start_time = time.perf_counter()

    def increment(self, inc: int = 1) -> None:
        """Increment the progress bar.

        Will not change the text on stderr if too little time has passed since last update.

        Arguments
        ---------
        inc : int, optional
            how many \"units of work\" have been done since last call
        """
        if self.status >= self.size:
            return
        if self.start_time == 0.0:
            self.start()

        now = time.perf_counter()
        self.status += inc

        if now - self.last_time > self.update_time:
            self.last_time = now
            elapsed = now - self.start_time
            remaining = elapsed / self.status * (self.size - self.status)
            self._update(remaining)

    def _make_bar(self) -> str:
        progress = self.status / self.size
        ticks = int(round(progress * self.bar_size))
        gaps = self.bar_size - ticks
        bar = ticks * "#" + gaps * "."
        return f"[{bar}]"

    def _update(self, remaining: float = None) -> None:
        bar = self._make_bar()
        if remaining is None:
            msg = f"{bar}"
        else:
            msg = f"{bar} Remaining: {format_sec(remaining)}"
        msg_len = len(msg)
        if msg_len < self.last_len:
            msg = msg + (self.last_len - msg_len) * " "
        self.last_len = msg_len
        print(f"\r{msg}", end="\r", flush=True, file=sys.stderr)

    def done(self) -> None:
        """Terminate the progress bar and print total time."""
        now = time.perf_counter()
        elapsed = now - self.start_time
        msg = f"Done in {format_sec(elapsed)}"
        msg_len = len(msg)
        if msg_len < self.last_len:
            msg = msg + (self.last_len - msg_len) * " "
        print(f"{msg}", file=sys.stderr)


_AEC_YELLOW = "\x1B[1;33m"
_AEC_RED = "\x1B[1;31m"
_AEC_RESET = "\x1B[0m"
