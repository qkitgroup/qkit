# Copyright (C) Intermodulation Products AB, 2018 - All Rights Reserved.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential. Please refer to file LICENSE for details.
"""
This is the Python public API for controlling the Vivace and Presto hardware platforms.

Detailed information is provided in the documentation for each module.

.. autosummary::
    :nosignatures:

    hardware
    lockin
    pulsed
    utils
    version
"""

from .version import version_api as __version__
